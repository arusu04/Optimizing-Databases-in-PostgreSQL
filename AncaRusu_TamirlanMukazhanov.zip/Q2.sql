-- Count the total number of distinct continents
WITH TotalContinents AS (
    SELECT COUNT(DISTINCT continent) AS count
    FROM country
),
-- Count the number of distinct continents for each feature class
FeatureContinents AS (
    SELECT f.class, COUNT(DISTINCT c.continent) AS count
    FROM feature f
    INNER JOIN geoitem g ON f.code = g.feature_code
    INNER JOIN country c ON g.country_code = c.iso
    GROUP BY f.class
)
-- Select the feature classes that are present in all continents
SELECT fc.code, fc.description
FROM featureclass fc
INNER JOIN FeatureContinents ON fc.code = FeatureContinents.class
CROSS JOIN TotalContinents
WHERE FeatureContinents.count = TotalContinents.count;
