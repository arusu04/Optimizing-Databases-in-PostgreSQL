SELECT country_code, COUNT(*) AS num_geoitems
FROM geoitem
GROUP BY country_code
ORDER BY num_geoitems DESC;

