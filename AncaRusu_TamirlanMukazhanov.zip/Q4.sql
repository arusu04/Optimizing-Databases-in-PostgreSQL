SELECT iso, country, population
FROM country
WHERE population > (SELECT AVG(population) FROM country);
