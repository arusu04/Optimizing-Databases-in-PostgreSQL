SELECT co.iso, co.country, f.code AS feature_code, f.name AS feature_name, COUNT(gi.geonameid) AS geoitem_count
FROM country co
JOIN geoitem gi ON co.iso = gi.country_code
JOIN feature f ON gi.feature_code = f.code
GROUP BY co.iso, co.country, f.code, f.name
HAVING COUNT(gi.geonameid) > 5;
