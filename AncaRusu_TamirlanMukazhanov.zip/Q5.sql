WITH CountryNeighbors AS (
    SELECT 
        c.iso AS country_iso,
        c.country AS country_name,
        regexp_split_to_table(c.neighbours, ',') AS neighbor_iso
    FROM 
        country c
),
MaxNeighborPop AS (
    SELECT 
        cn.country_iso,
        MAX(g.pop) AS max_neighbor_population
    FROM 
        CountryNeighbors cn
    JOIN 
        geoitem g ON g.country_code = cn.neighbor_iso
    GROUP BY 
        cn.country_iso
)
SELECT 
    c.country AS country_name,
    g.asciiname
FROM 
    geoitem g
JOIN 
    country c ON g.country_code = c.iso
JOIN 
    MaxNeighborPop mnp ON mnp.country_iso = c.iso
WHERE 
    g.pop > mnp.max_neighbor_population;

